const Sequelize = require ('sequelize');
const sequelize = new Sequelize ('crud', 'root', 'freitas2306',{
    dialect: 'mysql', 
    host: 'localhost',
    port: 3006
}) 

module.exports = sequelize;