(async () => {

const database = require ('./db');
const produto = require('./produto')
await database.sync();

const novoProduto = Produto.create({
    nome: 'Ps4',
    preco: 2000,
    descricao: 'Ps4 novo com 10 jogos'
})
console.log(novoProduto);

})();